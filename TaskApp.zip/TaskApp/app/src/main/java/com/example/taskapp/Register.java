package com.example.taskapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://taskapp-a4147-default-rtdb.firebaseio.com/");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        final EditText name = findViewById(R.id.name);
        final EditText number = findViewById(R.id.number);

        final Button registerBtn = findViewById(R.id.registerBtn);
        final TextView loginNowBtn = findViewById(R.id.loginNow);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //taking in data from editText into Strings

                final String emailTxt = email.getText().toString();
                final String passwordTxt = password.getText().toString();
                final String nameTxt = name.toString().toString();
                final String numberTxt = number.toString().toString();

                if(emailTxt.isEmpty() || passwordTxt.isEmpty() || nameTxt.isEmpty() || numberTxt.isEmpty()){
                    Toast.makeText(Register.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }else {

                    //chjeck if users have registered with this phone number before

                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.hasChild(numberTxt)){
                                Toast.makeText(Register.this, "Phone is already registered", Toast.LENGTH_SHORT).show();
                            }else {
                                //Setting all details of user are unique by the phone number

                                databaseReference.child("users").child(numberTxt).child("name").child(nameTxt);
                                databaseReference.child("users").child(numberTxt).child("email").child(emailTxt);
                                databaseReference.child("users").child(numberTxt).child("password").child(passwordTxt);

                                //checking to see if its successful with a toast message
                                Toast.makeText(Register.this, "User Registered succesfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
            }
        });

        loginNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }


}